#ifndef FS_H
#define FS_H

#include <type.h>
#define MAX_NAME_LEN 32
#define SECTOR_SIZE 512
#define BLOCK_SIZE 4096

// bit map
#define BIT_MAP_1 (1 << 0)
#define BIT_MAP_2 (1 << 1)
#define BIT_MAP_3 (1 << 2)
#define BIT_MAP_4 (1 << 3)
#define BIT_MAP_5 (1 << 4)
#define BIT_MAP_6 (1 << 5)
#define BIT_MAP_7 (1 << 6)
#define BIT_MAP_8 (1 << 7)
#define BIT_MAP_EXIST(a, b) ((a >> (b-1)) & (0x1))

#define FS_MAGIC 0x20010428
#define SUPERBLOCK_START       1024 
#define BLOCK_MAP_START_OFFS   1
#define BLOCK_MAP_NUM          64
#define INODE_MAP_START_OFFS   65
#define INODE_MAP_NUM          2
#define INODE_CHART_START_OFFS 67
#define INODE_CHART_NUM        64// re-calculate
#define DATA_BLOCK_START_OFFS  131
#define DATA_BLOCK_NUM         1 << 30

// inodes per sector
#define IPB (SECTOR_SIZE / sizeof(inode_t))

//MODE
#define READ_ONLY 0
#define WRITE_ONLY 1
#define READ_WRITE 2

//FILE TYPE
#define DIR 0
#define FILE 1

typedef struct inode{
    // int ino;
    size_t size;
    int mode;
    int file_type;
    int ref[11]; // block id
    int ref2[2];
    int num;
    //int ref3;
    /* QAQ */
}inode_t;

typedef struct dentry{
    int ino;
    char file_name[MAX_NAME_LEN];
    int file_type;
}dentry_t;

typedef struct superblock{
    int magic_num;
    int fs_size;

    int block_map_start;
    int block_map_num;

    int inode_map_start;
    int inode_map_num;

    int inode_chart_start;
    int inode_chart_num;

    int data_block_start;
    int data_block_num;
}superblock_t;

#define INODE_BLOCK_OF(ino) (ino/IPB + sup->inode_chart_start)

void init_fs();
void do_mkfs();
void do_statfs();
void do_mkdir(char* );
void do_rmdir(char* );
void do_cd(char* );
void do_ls();

extern superblock_t sup;

#endif
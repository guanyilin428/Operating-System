#include <os/sched.h>
#include <os/fs.h>
#include <os/string.h>
#include <assert.h>

int cur_ino = 1;
superblock_t sup;

void init_fs()
{
    printk("[FS] Start initialize file system!\n\r");
    printk("[FS] Setting superblock...\n\r");
    uint8_t *tmp = (uint8_t*)malloc(2 * SECTOR_SIZE);
    superblock_t* sup = (superblock_t*)tmp;
    sbi_sd_read(kva2pa(sup), 1, SUPERBLOCK_START);
    if (sup->magic_num != FS_MAGIC){
        sup->magic_num = FS_MAGIC;
        sup->block_map_start = SUPERBLOCK_START + BLOCK_MAP_START_OFFS;
        sup->block_map_num = BLOCK_MAP_NUM;
        sup->inode_map_start = SUPERBLOCK_START + INODE_MAP_START_OFFS;
        sup->inode_map_num = INODE_MAP_NUM;
        sup->inode_chart_start = SUPERBLOCK_START + INODE_CHART_START_OFFS;
        sup->inode_chart_num = INODE_CHART_NUM;
        sup->data_block_start = SUPERBLOCK_START + DATA_BLOCK_START_OFFS;
        sup->data_block_num = DATA_BLOCK_NUM;
        sbi_sd_write(kva2pa(sup), 1, SUPERBLOCK_START);

        // setting inode map
        printk("[FS] Setting inode-map...\n\r");
        kmemset(tmp, 0, 2 * SECTOR_SIZE);
        tmp[0] = BIT_MAP_1;
        sbi_sd_write(kva2pa(tmp), INODE_MAP_NUM, sup->inode_map_start);

        /* setting block map */
        printk("[FS] Setting block-map...\n\r");
        sbi_sd_write(kva2pa(tmp), 1, sup->block_map_start);
        tmp[0] = 0;
        for(int i = 1; i < BLOCK_MAP_NUM; i++){
            sbi_sd_write(kva2pa(tmp), 1, sup->block_map_start + i);
        }

        // setting dir
        inode_t *inode = (inode_t*)tmp;
        inode->num = 2;
        inode->mode = READ_WRITE;
        inode->file_type = DIR;
        inode->ref[0] = SUPERBLOCK_START + DATA_BLOCK_START_OFFS;
        sbi_sd_write(kva2pa(tmp), 1, sup->inode_chart_start);

        // setting root dir
        kmemset(tmp, 0, 2 * SECTOR_SIZE);
        dentry_t* dentry = (dentry_t*)tmp;
        kstrcpy(dentry->file_name, ".");
        dentry->file_type = DIR;
        dentry->ino = 1;
        dentry++;
        kstrcpy(dentry->file_name, "..");
        dentry->file_type = DIR;
        dentry->ino = 1;
        sbi_sd_write(kva2pa(tmp), 1, sup->data_block_start);
    }

    printk("     magic : 0x%x\n\r", sup->magic_num);
    printk("     start sector : %d\n\r", sup->block_map_start);
    printk("     block map start : %d(%d)\n\r", sup->block_map_start, sup->block_map_num);
    printk("     inode map start : %d(%d)\n\r", sup->inode_map_start, sup->inode_map_num);
    printk("     inode chart start : %d(%d)\n\r", sup->inode_chart_start, sup->inode_chart_num);
    printk("     data block start : %d(%d)\n\r", sup->data_block_start, sup->data_block_num);
    printk("     inode entry size : %dB, dir entry size : %dB\n\r", sizeof(inode_t), sizeof(dentry_t));

}

void do_mkfs(){
    prints("[FS] Start initialize file system!\n");
    prints("[FS] Setting superblock...\n");
    uint8_t *tmp = (uint8_t*)malloc(2 * SECTOR_SIZE);
    superblock_t* sup = (superblock_t*)tmp;
    sup->magic_num = FS_MAGIC;
    sup->block_map_start = SUPERBLOCK_START + BLOCK_MAP_START_OFFS;
    sup->block_map_num = BLOCK_MAP_NUM;
    sup->inode_map_start = SUPERBLOCK_START + INODE_MAP_START_OFFS;
    sup->inode_map_num = INODE_MAP_NUM;
    sup->inode_chart_start = SUPERBLOCK_START + INODE_CHART_START_OFFS;
    sup->inode_chart_num = INODE_CHART_NUM;
    sup->data_block_start = SUPERBLOCK_START + DATA_BLOCK_START_OFFS;
    sup->data_block_num = DATA_BLOCK_NUM;
    sbi_sd_write(kva2pa(sup), 1, SUPERBLOCK_START);

    prints("     magic : 0x%x\n", sup->magic_num);
    prints("     start sector : %d\n", sup->block_map_start);
    prints("     block map start : %d(%d)\n", sup->block_map_start, sup->block_map_num);
    prints("     inode map start : %d(%d)\n", sup->inode_map_start, sup->inode_map_num);
    prints("     inode chart start : %d(%d)\n", sup->inode_chart_start, sup->inode_chart_num);
    prints("     data block start : %d(%d)\n", sup->data_block_start, sup->data_block_num);
    prints("     inode entry size : %dB, dir entry size : %dB\n", sizeof(inode_t), sizeof(dentry_t));

    // setting inode map
    printk("[FS] Setting inode-map...\n\r");
    kmemset(tmp, 0, 2 * SECTOR_SIZE);
    tmp[0] = BIT_MAP_1;
    sbi_sd_write(kva2pa(tmp), INODE_MAP_NUM, sup->inode_map_start);

    /* setting block map */
    printk("[FS] Setting block-map...\n\r");
    sbi_sd_write(kva2pa(tmp), 1, sup->block_map_start);
    tmp[0] = 0;
    for(int i = 1; i < BLOCK_MAP_NUM; i++){
        sbi_sd_write(kva2pa(tmp), 1, sup->block_map_start + i);
    }

    // setting dir
    inode_t *inode = (inode_t*)tmp;
    inode->num = 2;
    inode->mode = READ_WRITE;
    inode->file_type = DIR;
    inode->ref[0] = SUPERBLOCK_START + DATA_BLOCK_START_OFFS;
    sbi_sd_write(kva2pa(tmp), 1, sup->inode_chart_start);

    // setting root dir
    kmemset(tmp, 0, 2 * SECTOR_SIZE);
    dentry_t* dentry = (dentry_t*)tmp;
    kstrcpy(dentry->file_name, ".");
    dentry->file_type = DIR;
    dentry->ino = 1;
    dentry++;
    kstrcpy(dentry->file_name, "..");
    dentry->file_type = DIR;
    dentry->ino = 1;
    sbi_sd_write(kva2pa(tmp), 1, sup->data_block_start);
}

void do_statfs(){
    int i, j;
    uint8_t *tmp = (uint8_t*)malloc(SECTOR_SIZE);
    superblock_t* sup = (superblock_t*)tmp;
    sbi_sd_read(kva2pa(sup), 1, SUPERBLOCK_START);
    prints("     magic : 0x%x (KFS).\n", sup->magic_num);
    prints("     start sector : %d\n", sup->block_map_start);
    prints("     block map start : %d(%d)\n", sup->block_map_start, sup->block_map_num);
    prints("     inode map start : %d(%d)\n", sup->inode_map_start, sup->inode_map_num);
    prints("     inode chart start : %d(%d)\n", sup->inode_chart_start, sup->inode_chart_num);
    prints("     data block start : %d(%d)\n", sup->data_block_start, sup->data_block_num);
    prints("     inode entry size : %dB, dir entry size : %dB\n", sizeof(inode_t), sizeof(dentry_t));
    
    int used_num = 0;
    for(i = 0; i < INODE_MAP_NUM; i++){
        sbi_sd_read(kva2pa(tmp), 1, sup->inode_map_start + i);
        for(j = 0; j < SECTOR_SIZE; j++){
            used_num += BIT_MAP_EXIST(tmp[j], 1) + BIT_MAP_EXIST(tmp[j], 2) + 
                        BIT_MAP_EXIST(tmp[j], 3) + BIT_MAP_EXIST(tmp[j], 4) +
                        BIT_MAP_EXIST(tmp[j], 5) + BIT_MAP_EXIST(tmp[j], 6) +
                        BIT_MAP_EXIST(tmp[j], 7) + BIT_MAP_EXIST(tmp[j], 8);  
        }
    }
    prints("     inode used %d/%d\n", used_num, sup->inode_map_num * 8);

    memset(tmp, 0, SECTOR_SIZE);
    used_num = 0;
    for(i = 0; i < BLOCK_MAP_NUM; i++){
        sbi_sd_read(kva2pa(tmp), 1, sup->block_map_start + i);
        for(j = 0; j < SECTOR_SIZE; j++){
            used_num += BIT_MAP_EXIST(tmp[j], 1) + BIT_MAP_EXIST(tmp[j], 2) + 
                        BIT_MAP_EXIST(tmp[j], 3) + BIT_MAP_EXIST(tmp[j], 4) +
                        BIT_MAP_EXIST(tmp[j], 5) + BIT_MAP_EXIST(tmp[j], 6) +
                        BIT_MAP_EXIST(tmp[j], 7) + BIT_MAP_EXIST(tmp[j], 8);  
        }
    }
    prints("     block used %d/%d\n", used_num, sup->block_map_num * 8);
    screen_reflush();
}

int get_dir_ino(char* name, int ino, char* tmp, superblock_t* sup){
    if(!kstrlen(name))
        return ino;
    
    // get inode
    int inode_block = ino/IPB + sup->inode_chart_start;
    kmemset(tmp, 0, SECTOR_SIZE);
    sbi_sd_read(kva2pa(tmp), 1, inode_block);
    inode_t* inode = (inode_t*)(tmp + (ino % IPB) * sizeof(inode_t));
    if(inode->file_type == FILE)
        return -1; //err
            
    // get dentry (size??)
    kmemset(tmp, 0, SECTOR_SIZE);
    sbi_sd_read(kva2pa(tmp), 1, inode->ref[0]);
    dentry_t* dentry = (dentry_t*)tmp;

    // match dir_name
    char* cur_name[MAX_NAME_LEN] = {0};
    //kmemset(cur_name, 0, MAX_NAME_LEN);
    name = kstrtok(cur_name, name, '/', MAX_NAME_LEN);
    for(int i = 0; i < inode->num; i++){
        if(!kstrcmp(dentry[i].file_name, cur_name)){
            if(dentry[i].file_type == FILE)
                return -1;
            return get_dir_ino(name, dentry->ino, tmp, sup);
        }
    }
    return -1; // failed to match name
}

void do_cd(char* name){
    // get superblock and alloc tmp
    uint8_t suptmp[512];
    superblock_t* sup = (superblock_t *)suptmp;
    sbi_sd_read(kva2pa(sup), 1, SUPERBLOCK_START);

    uint8_t tmp = (uint8_t*)malloc(SECTOR_SIZE * sizeof(uint8_t));
    kmemset(tmp, 0, SECTOR_SIZE);

    if(name[0] == '/'){
        cur_ino = get_dir_ino(&name[1], 1, tmp, sup);
    }
}

static int alloc_inode(){
    int new_ino;
    char tmp[SECTOR_SIZE];

    // uint8_t tmp = (uint8_t*)malloc(INODE_MAP_NUM * SECTOR_SIZE * sizeof(uint8_t));
    
    for(int i = 0; i < sup->inode_map_num; i++){
        sbi_sd_read(kva2pa(tmp), 1, sup->inode_map_start + i);
        for (int j = 0; j < SECTOR_SIZE; j++)
        {
            if(tmp[j] == 0xff)
                continue;
            for(int k = 1; k <= 8; k++){
                if(BIT_MAP_EXIST(tmp[j], k) == 0){
                    tmp[j] |= 1 << (k - 1);
                    new_ino = i * 8 * SECTOR_SIZE + j * 8 + k;
                    sbi_sd_write(kva2pa(tmp), 1, sup->inode_map_start + i);
                    return new_ino;
                }
            }
        }
    }
    assert(0);
}

static int alloc_block(){
    int new_block;
    char tmp[SECTOR_SIZE];

    // uint8_t tmp = (uint8_t*)malloc(INODE_MAP_NUM * SECTOR_SIZE * sizeof(uint8_t));
    
    for(int i = 0; i < sup->block_map_num; i++){
        sbi_sd_read(kva2pa(tmp), 1, sup->block_map_start + i);
        for (int j = 0; j < SECTOR_SIZE; j++)
        {
            if(tmp[j] == 0xff)
                continue;
            for(int k = 1; k <= 8; k++){
                if(BIT_MAP_EXIST(tmp[j], k) == 0){
                    tmp[j] |= 1 << (k - 1);
                    new_block = i * 8 * SECTOR_SIZE + j * 8 + k;
                    sbi_sd_write(kva2pa(tmp), 1, sup->block_map_start + i);
                    return new_block;
                }
            }
        }
    }
    assert(0);
}

void do_mkdir(char* name){

    uint8_t tmp = (uint8_t*)malloc(SECTOR_SIZE * sizeof(uint8_t));
    kmemset(tmp, 0, SECTOR_SIZE);

    //check fs??
    if (!kstrcmp(name, ".") || !kstrcmp(name, "..")){
        prints("illegal directory name.\n");
        return;
    }

    // get parent_dir name
    char* par_name[MAX_NAME_LEN] = {0};
    char* new_dir_name[MAX_NAME_LEN] = {0};
    kstrcpy(par_name, name);
    int len = kstrlen(name);
    for(int i = len; i; i--){
        if(par_name[i] == '/')
            break;
        par_name[i] = '\0';
    }
    // get new_dir_name
    int par_len = kstrlen(par_name);
    for(int i = 0; i < len - par_len; i++)
        new_dir_name[i] = name[i + par_len];

    int par_ino = get_dir_ino(par_name, 1, tmp, sup);

    // get inode
    sbi_sd_read(kva2pa(tmp), 1, INODE_BLOCK_OF(par_ino));
    inode_t* inode = (inode_t*)(tmp + (par_ino % IPB) * sizeof(inode_t));
    int parent_dir_blocknum = inode->ref[0];
    // check parent directory
    sbi_sd_read(kva2pa(tmp), 1, parent_dir_blocknum);
    dentry_t* dentry = (dentry_t*)tmp;
    for(int i = 0; i < inode->num; i++){
        if(dentry->ino && dentry->file_type == DIR && !kstrcmp(dentry->file_name, new_dir_name)){
            //found
            prints("err: directory already existed.\n");
            return;
        }
        dentry++;
    }

    /* Now it's OK to make a new directory */ 
    // alloc and set new inode
    int new_ino = alloc_inode();
    sbi_sd_read(kva2pa(tmp), 1, INODE_BLOCK_OF(new_ino));
    inode_t* new_inode = (inode_t*)(tmp + (new_ino % IPB) * sizeof(inode_t));
    new_inode->file_type = DIR;
    new_inode->mode = READ_WRITE;
    int new_block = alloc_block();
    new_inode->ref[0] = new_block;
    new_inode->num = 2;
    sbi_sd_write(kva2pa(tmp), 1, INODE_BLOCK_OF(new_ino));

    // setting . and .. for new directory
    kmemset(tmp, 0, SECTOR_SIZE);
    dentry_t *dentry2 = (dentry_t*)tmp;
    kstrcpy(dentry2->file_name, ".");
    dentry2->file_type = DIR;
    dentry2->ino = new_ino;
    dentry2++;
    kstrcpy(dentry2->file_name, "..");
    dentry2->file_type = DIR;
    dentry2->ino = par_ino;
    sbi_sd_write(kva2pa(tmp), 1, new_block);

    // modify parent directory
    sbi_sd_read(kva2pa(tmp), 1, parent_dir_blocknum);
    kstrcpy(dentry->file_name, new_dir_name);
    dentry->file_type = DIR;
    dentry->ino = new_ino;
    sbi_sd_write(kva2pa(tmp), 1, parent_dir_blocknum);

    // modify parent inode
    sbi_sd_read(kva2pa(tmp), 1, INODE_BLOCK_OF(par_ino));
    inode->num++;
    sbi_sd_write(kva2pa(tmp), 1, INODE_BLOCK_OF(par_ino));
    
}

